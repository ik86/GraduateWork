import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import java.io.*;
//import project.*;
public class TransactionProcessor1 extends JFrame
{
	private JMenuItem Item,Item1,Item2,Item3,Item4,Item5;
	private BankUI userInterface;
	private JTextField fields[],accountField,transactionField;
	private JButton actionButton,cancelButton;
	private FileEditor dataFile;
	private RandomAccessAccountRecord record;
	public TransactionProcessor1()
	{
		super("TransactionProcess");

		//set up desktop,menubar and filemenu
		userInterface=new BankUI(5);
		getContentPane().add(userInterface);
		userInterface.setVisible(false);
		//set up action button
		actionButton=userInterface.getDoTask1Button();
		actionButton.setText("save changes");
		actionButton.setEnabled(false);

		//register action button listener
		actionButton.addActionListener(

			new ActionListener()
			{
				public void actionPerformed(ActionEvent e)
				{
					String action=e.getActionCommand();
					performAction(action);
				}
			}
			);
			//set up cancel button
			cancelButton=userInterface.getDoTask2Button();
					cancelButton.setText("cancel changes");
					cancelButton.setEnabled(false);

					//register cancel button listener
					cancelButton.addActionListener(

						new ActionListener()
						{
							public void actionPerformed(ActionEvent e)
							{
								userInterface.clearFields();
							}
						}
			);
			//set up listener for the account field
			fields=userInterface.getFields();
			accountField=fields[BankUI.ACCOUNT];
			accountField.addActionListener(

						new ActionListener()
						{
							public void actionPerformed(ActionEvent e)
							{
								displayRecord("0");
							}
						}
			);
		//create referance to the transaction field
		transactionField=fields[BankUI.TRANSACTION];
		transactionField.addActionListener(

								new ActionListener()
								{
									public void actionPerformed(ActionEvent e)
									{
										displayRecord(transactionField.getText());
									}
								}
			);
		JMenu filemenu=new JMenu("File");
		filemenu.setMnemonic('F');
		Item=new JMenuItem("Open File");
		filemenu.add(Item);
		Item1=new JMenuItem("New File");
		filemenu.add(Item1);
		//Register New/Open Item Listener
		Item1.addActionListener(
			new ActionListener(){
				public void actionPerformed(ActionEvent e)
				{
					//Try to open file
					if(!openFile())
					return;
					//Setup the menu items
					Item2.setEnabled(true);
					Item3.setEnabled(true);
					Item4.setEnabled(true);
					Item1.setEnabled(false);
					//Set up the interface
					userInterface.setVisible(true);
					fields[BankUI.ACCOUNT].setEnabled(false);
					fields[BankUI.FIRSTNAME].setEnabled(false);
					fields[BankUI.LASTNAME].setEnabled(false);
					fields[BankUI.BALANCE].setEnabled(false);
					fields[BankUI.TRANSACTION].setEnabled(false);
				}
			}
		);
		filemenu.addSeparator();
		Item2=new JMenuItem("New Record");
		filemenu.add(Item2);
		Item2.setEnabled(false);
		Item2.addActionListener(
			new ActionListener()
			{
				public void actionPerformed(ActionEvent e)
				{
					fields[BankUI.ACCOUNT].setEnabled(true);
					fields[BankUI.FIRSTNAME].setEnabled(true);
					fields[BankUI.LASTNAME].setEnabled(true);
					fields[BankUI.BALANCE].setEnabled(true);
					fields[BankUI.TRANSACTION].setEnabled(false);
					actionButton.setEnabled(true);
					actionButton.setText("Create");
					cancelButton.setEnabled(true);
					userInterface.clearFields();
				}
			}
		);
		Item3=new JMenuItem("Update Record");
		filemenu.add(Item3);
		Item3.setEnabled(false);
		Item3.addActionListener(
					new ActionListener()
					{
						public void actionPerformed(ActionEvent e)
						{
							fields[BankUI.ACCOUNT].setEnabled(true);
							fields[BankUI.FIRSTNAME].setEnabled(false);
							fields[BankUI.LASTNAME].setEnabled(false);
							fields[BankUI.BALANCE].setEnabled(false);
							fields[BankUI.TRANSACTION].setEnabled(true);
							actionButton.setEnabled(true);
							actionButton.setText("Update");
							cancelButton.setEnabled(true);
							userInterface.clearFields();
						}
					}
		);
		Item4=new JMenuItem("Delete Record");
		filemenu.add(Item4);
		Item4.setEnabled(false);
		Item4.addActionListener(
					new ActionListener()
					{
						public void actionPerformed(ActionEvent e)
						{
							fields[BankUI.ACCOUNT].setEnabled(true);
							fields[BankUI.FIRSTNAME].setEnabled(false);
							fields[BankUI.LASTNAME].setEnabled(false);
							fields[BankUI.BALANCE].setEnabled(false);
							fields[BankUI.TRANSACTION].setEnabled(false);
							actionButton.setEnabled(true);
							actionButton.setText("Delete");
							cancelButton.setEnabled(true);
							userInterface.clearFields();
						}
					}
		);
		filemenu.addSeparator();
		Item5=new JMenuItem("Exit");
		filemenu.add(Item5);
		Item5.addActionListener(
			new ActionListener()
			{
				public void actionPerformed(ActionEvent e)
				{
					try
					{
						dataFile.closeFile();
					}
					catch(IOException ioexception)
					{
						JOptionPane.showMessageDialog(TransactionProcessor.this,"Error closing file","IO Error",JOptionPane.ERROR_MESSAGE);
					}
					finally
					{
						System.exit(0);
					}
				}
			}
		);
		JMenuBar bar=new JMenuBar();
		setJMenuBar(bar);
		bar.add(filemenu);
		setSize(500,200);
		setVisible(true);
	}

	public static void main(String args[])
	{
		new TransactionProcessor();
	}

//get the file name and open the file
private boolean openFile()
{
	JFileChooser fileChooser=new JFileChooser();
	fileChooser.setFileSelectionMode(JFileChooser.FILES_ONLY);
	int result=fileChooser.showOpenDialog(this);

	//if user clicked cancel button on dialog.return
	if(result==JFileChooser.CANCEL_OPTION)
	return false;

	//obtain selected file
	File fileName=fileChooser.getSelectedFile();
	//display error if file name invalid

	if(fileName==null||fileName.getName().equals(" "))
	{
		JOptionPane.showMessageDialog(this,"invalid file name","bad file name",JOptionPane.ERROR_MESSAGE);
		return false;
	}
	try{
		//call the helper method to call the file
		dataFile=new FileEditor(fileName);
	}
	catch(IOException ioException){
		JOptionPane.showMessageDialog(this,"error opening file","IO error",JOptionPane.ERROR_MESSAGE);

	return false;
}
return true;
}
//end method open file
//create,update or delete a record
private void performAction(String action)
{
	try	{
		//GET THE TEXT FIELD value
		String[] values=userInterface.getFieldValues();
		int accountNumber=Integer.parseInt(values[BankUI.ACCOUNT]);
		String firstName=values[BankUI.FIRSTNAME];
        String lastName=values[BankUI.LASTNAME];
        double balance=Double.parseDouble(values[BankUI.BALANCE]);

        if(action.equals("Create"))
        dataFile.newRecord(accountNumber,firstName,lastName,balance);
        else if(action.equals("Update"))
        dataFile.updateRecord(accountNumber,firstName,lastName,balance);
        else if(action.equals("Delete"))
        dataFile.deleteRecord(accountNumber);
        else
        JOptionPane.showMessageDialog(this,"invalid error","error executing action",JOptionPane.ERROR_MESSAGE);
	}
	//end try
	catch(NumberFormatException format)
	{JOptionPane.showMessageDialog(this,"Bad Input","Number Format Error",JOptionPane.ERROR_MESSAGE);
	}
	catch(IllegalArgumentException badAccount)
	{
		JOptionPane.showMessageDialog(this,badAccount.getMessage(),"Bad Account Number",JOptionPane.ERROR_MESSAGE);
	}
	catch(IOException ioException)
	{
			JOptionPane.showMessageDialog(this,"Error Writing to the File","IO Error",JOptionPane.ERROR_MESSAGE);
	}
}
private void displayRecord(String transaction)
{
	try
	{
		//get account number
		int accountNumber=Integer.parseInt(userInterface.getFieldValues()[BankUI.ACCOUNT]);
		//GET THE ASSOCIATED RECORD
		RandomAccessAccountRecord record=dataFile.getRecord(accountNumber);
		if(record.getAccount()==0)
		JOptionPane.showMessageDialog(this,"Record Does Not Exist","bad account number",JOptionPane.ERROR_MESSAGE);
	//get the transaction
	double change=Double.parseDouble(transaction);
	//create a string array
	String[] values={String.valueOf(record.getAccount()),
	record.getFirstName(),record.getLastName(),
	String.valueOf(record.getBalance()+change),
	"Charge(+) or payment(-)"};
	userInterface.setFieldValues(values);
}
//end try
catch(NumberFormatException format)
	{JOptionPane.showMessageDialog(this,"Bad Input","Number Format Error",JOptionPane.ERROR_MESSAGE);
	}
	catch(IllegalArgumentException badAccount)
	{
		JOptionPane.showMessageDialog(this,badAccount.getMessage(),"Bad Account Number",JOptionPane.ERROR_MESSAGE);
	}
	catch(IOException ioException)
	{
			JOptionPane.showMessageDialog(this,"Error Writing to the File","IO Error",JOptionPane.ERROR_MESSAGE);
	}
}
}

